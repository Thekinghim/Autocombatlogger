-- Main Addon Frame
local AutoCombatLogger = CreateFrame("Frame", "AutoCombatLoggerFrame", UIParent, "BasicFrameTemplateWithInset")
AutoCombatLogger:SetSize(215, 130) -- Adjusted frame size for a more compact UI
AutoCombatLogger:SetPoint("CENTER")
AutoCombatLogger:SetMovable(true)
AutoCombatLogger:EnableMouse(true)
AutoCombatLogger:RegisterForDrag("LeftButton")
AutoCombatLogger:SetScript("OnDragStart", AutoCombatLogger.StartMoving)
AutoCombatLogger:SetScript("OnDragStop", AutoCombatLogger.StopMovingOrSizing)
AutoCombatLogger:Hide()

-- Title setup
AutoCombatLogger.title = AutoCombatLogger:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
AutoCombatLogger.title:SetPoint("TOP", 0, -3)
AutoCombatLogger.title:SetText("Auto Logger")

-- Status Text
AutoCombatLogger.statusText = AutoCombatLogger:CreateFontString(nil, "OVERLAY", "GameFontNormal")
AutoCombatLogger.statusText:SetPoint("TOP", AutoCombatLogger.title, "BOTTOM", 0, -8)
AutoCombatLogger.statusText:SetText("Logging: |cff00ff00Enabled|r") -- Default to enabled; will update on PLAYER_LOGIN

-- Update Status Function
local function UpdateStatus()
    if LoggingCombat() then
        AutoCombatLogger.statusText:SetText("Logging: |cff00ff00Enabled|r")
        DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Combat Logging is ENABLED|r")
    else
        AutoCombatLogger.statusText:SetText("Logging: |cffff0000Disabled|r")
        DEFAULT_CHAT_FRAME:AddMessage("|cffff0000Combat Logging is DISABLED|r")
    end
end

-- Toggle Logging Function
local function ToggleLogging()
    LoggingCombat(not LoggingCombat())
    UpdateStatus()
end

-- Toggle Button
local toggleButton = CreateFrame("Button", nil, AutoCombatLogger, "UIPanelButtonTemplate")
toggleButton:SetSize(180, 22)
toggleButton:SetPoint("TOP", AutoCombatLogger.statusText, "BOTTOM", 0, -4)
toggleButton:SetText("Toggle Logging")
toggleButton:SetScript("OnClick", ToggleLogging)

-- Check Status Button
local checkButton = CreateFrame("Button", nil, AutoCombatLogger, "UIPanelButtonTemplate")
checkButton:SetSize(180, 22)
checkButton:SetPoint("TOP", toggleButton, "BOTTOM", 0, -2)
checkButton:SetText("Check Status")
checkButton:SetScript("OnClick", UpdateStatus)

-- Hide Button
local hideButton = CreateFrame("Button", nil, AutoCombatLogger, "UIPanelButtonTemplate")
hideButton:SetSize(180, 22)
hideButton:SetPoint("TOP", checkButton, "BOTTOM", 0, -2)
hideButton:SetText("Hide")
hideButton:SetScript("OnClick", function()
    AutoCombatLogger:Hide()
end)

-- Minimap Button Placeholder
local minimapButton = CreateFrame("Button", "AutoCombatLoggerMinimapButton", Minimap)
minimapButton:SetSize(32, 32)
minimapButton:SetFrameStrata("MEDIUM")
minimapButton:SetFrameLevel(8)
minimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT")
minimapButton.icon = minimapButton:CreateTexture(nil, "BACKGROUND")
minimapButton.icon:SetSize(32, 32)
minimapButton.icon:SetTexture("Interface\\Addon\\INV_Misc_QuestionMark") -- Placeholder icon
minimapButton.icon:SetPoint("CENTER")
-- Placeholder functionality: show the main frame when the icon is clicked
minimapButton:SetScript("OnClick", function()
    AutoCombatLogger:Show()
end)

-- Slash Command for Toggling the Frame
SLASH_AUTOLOG1 = "/autolog"
SlashCmdList["AUTOLOG"] = function()
    if AutoCombatLogger:IsShown() then
        AutoCombatLogger:Hide()
    else
        AutoCombatLogger:Show()
    end
    UpdateStatus()
end

-- Event Handling for Automatic Logging
AutoCombatLogger:RegisterEvent("PLAYER_LOGIN")
AutoCombatLogger:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        UpdateStatus()
    end
end)

-- Ensure the status text is updated correctly on login
UpdateStatus()
