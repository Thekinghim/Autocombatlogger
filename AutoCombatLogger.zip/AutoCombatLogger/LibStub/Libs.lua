---@class Arenalogs
local Arenalogs = select(2, ...)

---@type GGUI-2.1
Arenalogs.GGUI = LibStub:GetLibrary("GGUI-2.1")

---@type GUTIL-2.0
Arenalogs.GUTIL = LibStub:GetLibrary("GUTIL-2.0")
