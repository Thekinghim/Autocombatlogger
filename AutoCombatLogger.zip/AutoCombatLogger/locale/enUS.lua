local L = LibStub("AceLocale-3.0"):NewLocale("MyVaultList", "enUS", true)

if not L then
    return
end

L["Character"] = "Character"
L["Raids"] = "Raids"
L["Activities"] = "Activities"
L["PvP"] = "PvP"
L["iLevel"] = "Item Level"
L["Mythic"] = "Mythic"
L["Boss List"] = "Boss List"
L["Keys"] = "Keys"
